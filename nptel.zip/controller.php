<?php

if(isset($_GET['a']))
{
    if(file_exists(('nptel_enroll/'.$_GET['a'].".php")))
    {
        include('nptel_enroll/'.$_GET['a'].".php");
    }
    else
    {
        print '<h4>Warning ! You are trying to violating our system.</h4>';
        var_dump($_SERVER);
    }
}
else
{
    include('nptel_enroll/student_add.php');
}


?>