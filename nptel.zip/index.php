<?php
$cn = mysqli_connect("localhost", "root", "", "nptel_enroll");
?>
<!doctype html>
<html lang="en">
<head>
    <!--============================= Fonts =======================================-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100i,300,300i,400,700" rel="stylesheet">
    <!--============================= CSS =======================================-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="assets/js/jquery-3.2.1.slim.min.js"></script>
    <title>NPTEL-Enrollment</title>
    <link rel="shourtcut icon" type="image/png" href="assets/img/favicon.png">
</head>
<body>
    <!--================= Header-area ======================-->
    <div class="header-area header-absoulate">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="">
                            <img src="assets/img/favicon.png">
                            <span>NPTEL <span id="na"></span></span>
                        </a>
                    </div>
                </div>
    <!--================== Main menu-area ====================-->
                <div class="col-md-7">
                    <div class="main-menu">
                        <?php include('menu.php'); ?>
                    </div>
                </div>
                <div class="col-md-1 text-right">
                    <span class="social-icon">
                        <a href="https://www.facebook.com/NPTELNoc/"><i class="fa fa-facebook"></i></a>
                        <a href="https://twitter.com/nptelindia"><i class="fa fa-twitter"></i></a>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <!--======================= Slide-area =======================-->
    <div class="welcome-area">
        <div class="owl-carousel slider-content">
            <div class="single-slider-item slider-bg-1">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="slide-text">
                                    <h2>National Programme for Technology Enhanced
									Learning</h2>
                                    <p>is a joint initiative from IITs and IISc to offer online courses and 
									certification in various topics
                                     Learn for free; Pay a small fee to write an exam and get a certificate
                                    </p>

                                    <a href="https://nptel.ac.in/" class="boxed-btn">learn more <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item slider-bg-2">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="slide-text">
                                     <h2>National Programme for Technology Enhanced 
									 Learning</h2>
                                    <p>is a joint initiative from IITs and IISc to offer online courses 
									   and certification in various topics
                                     Learn for free; Pay a small fee to write an exam and get a certificate
                                    </p>
                                    <a href="https://nptel.ac.in/" class="boxed-btn">learn more <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--=========================== Content-area ============================-->
    <div class="content-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <?php include ('controller.php'); ?>

                </div>
            </div>
        </div>
    </div>
    <!--========================== Footer-area ===============================-->
    <footer>
        <div class="container">
            <div class="row">
                <P> Developed by Kewin Daniel</p>
                <p class="copy-right">Copyright &copy;NPTEL -2020</p>
            </div>
        </div>
    </footer>
    <!--  JavaScript -->
    <script src="assets/js/popper-1.12.9.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>