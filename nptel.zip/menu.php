<ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="?a=student_add">Enroll Course</a></li>
    <li><a href="?a=view">Students list</a></li>

</ul>
