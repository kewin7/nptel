<?php


$sql= "select * from course"; 	
$subject = mysqli_query($cn, $sql);
    $sname = "";
    $dob = "";
    $photo = "";
    $email = "";
    $address = "";
    $course = "";
					
    $esname = "";
    $edob = "";
    $ephoto = "";
    $eemail = "";
    $eaddress = "";
    $ecourse = "";


    $sql = "select * from stud_enroll where id = ".$_GET['eid'];
    $table = mysqli_query($cn, $sql);
    $row = mysqli_fetch_assoc($table);
					
	if(isset($_POST['submit']))
	{
	$sname = $_POST['sname'];
	$dob = $_POST['dob'] ;
	$email = $_POST['email'];
	$address = $_POST['address'];
	$course = $_POST['course'];
						
    $er = 0;
						
    if($sname == "")
    {
        $er++;
        $esname = "*Required";
    }
    else
    {
        $sname = test_input($sname);
        if(!preg_match("/^[a-zA-Z ]*$/",$sname)){
            $er++;
            $esname = "*Only letters and white space allowed";
        }
    }

    if($dob == "")
    {
        $er++;
        $edob = "*Required";
    }

  
        if($email == "")
        {
            $er++;
            $eemail = "*Required";
        }
        else
        {
            $email = test_input($email);
            if(!filter_var($email, FILTER_VALIDATE_EMAIL))
            {
                $er++;
                $eemail = "*Email format is invalid";
            }
            
        }

        if($address == "")
        {
            $er++;
            $eaddress = "*Required";
        }

        if($course == "")
        {
            $er++;
            $ecourse = "*Please select course";
        }
        if($er == 0)
        {
			
			if(count($_FILES) > 0) {
			if(is_uploaded_file($_FILES['image']['tmp_name'])) {
				$imgData =addslashes(file_get_contents($_FILES['image']['tmp_name']));
				$imageProperties = getimageSize($_FILES['image']['tmp_name']);
							
            $sql = "update stud_enroll set sname = '".strip_tags($sname)."', 
            dob = '".strip_tags($dob)."',
            email = '".strip_tags($email)."',
            address = '".strip_tags($address)."',
            course = '".strip_tags($course)."', photo ='{$imgData}', imageType ='{$imageProperties['mime']}' where id = ".$_GET['eid'];
            if(mysqli_query($cn, $sql))
            {
                print '<span class = "successMessage">Data update successfully</span>';
                $row['sname'] = "";
                $row['dob'] = "";
                $row['image'] = "";
                $row['email'] = "";
                $row['address'] = "";
                $row['course'] = "";
            }
            else
            {
                print '<span>'.mysqli_error($cn).'</span>';
            }
        }
    }
	}}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>


<div class="form-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3 id="et">Edit the ID:
                        <?php print $_GET['eid'].', Name: '.$row["sname"]; ?>'s information</h3>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="left-side-form">
                                        <h5><label for="sname">Student name</label>
                                            <span class="error">
                                                <?php print $esname; ?></span></h5>
                                        <p><input type="text" name="sname" value="<?php print $row['sname']; ?>"></p>
                                        <h5><label for="email">email</label><span class="error">
                                                <?php print $eemail; ?></span></h5>
                                        <p><input type="text" name="email" value="<?php print $row['email']; ?>"></p>

                                        <h5><label for="address">address</label><span class="error">
                                                <?php print $eaddress; ?></span></h5>
                                        <p><textarea name="address"><?php print $row['address']; ?></textarea></p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="right-side-form">
                                      <h5><label for="dob">Date of Birth</label><span class="error">
                                                <?php print $edob; ?></span></h5>
                                        <p><input type="text" name="dob" value="<?php print $row['dob']; ?>"></p>
                                      <h5><label for="photo">photo</label><span class="error">
                                                <?php print $ephoto; ?></span></h5>
                                        <p><input type="file" name="image" ></p>

                                        <h5><label for="course">course</label></h5>
                                        <p><select name="course" id="">
                                                <?php
                                                 foreach($subject as $row) { ?>
                                                 <option value="<?php echo $row['courseshort']; ?>"><?php echo $row['coursename']; ?></option>
                                               <?php
                                               } ?>  
                                            </select><span class="error">
                                                <?php print $ecourse; ?></span></p>

                                        <p><input type="submit" name="submit" value="Save Change"></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
