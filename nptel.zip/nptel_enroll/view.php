<div id="padding">
<div class="section-title">
    <h3>Enrolled Students list</h3>
</div>

        <?php 
        if(isset($_GET['did']))
        {
        delete();
        print '<h6 class= "successMessage">Student Deleted.</h6>';
        }
               
				$sql = "select * from stud_enroll";
				$table = mysqli_query($cn, $sql);
				print '<table>';
				print '<tr><th>ID</th><th>Student Name</th><th>Date of Birth</th><th>Photo</th><th>Email</th><th>Address</th><th>Course</th><th>Action</th></tr>';
				while($row = mysqli_fetch_assoc($table))
				{
					print '<tr>';
					print '<td>'.htmlentities($row["id"]).'</td>';
					print '<td>'.htmlentities($row["sname"]).'</td>';
					print '<td>'.htmlentities($row["dob"]).'</td>';
					print '<td><img src="data:image/jpeg;base64,'.base64_encode($row['photo']).'" height="100px"; /></td>';
					print '<td>'.htmlentities($row["email"]).'</td>';
					print '<td>'.htmlentities($row["address"]).'</td>';
					print '<td>'.htmlentities($row["course"]).'</td>';
					print '<td> <a class= "action-e" href= "?a=edit&eid='.$row["id"].'"><i class="fa fa-wrench" title="Update"></i></a>
					<a class= "action-d" href= "?a='.$_GET['a'].'&did='.$row['id'].'"><i class="fa fa-trash" title="Delete"></i></a></td>';
					print '</tr>';
				}
	
				print '</table>';


    function delete()
        {
            global $cn;
            $sql = "delete from stud_enroll where id = ".$_GET['did'];
            mysqli_query($cn, $sql);
        }
	
    ?>
     
</div>